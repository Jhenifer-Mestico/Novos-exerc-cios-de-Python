contador = 0

for indice in range(3):
    frase = input (' Digite uma frase:')
    contador = contador + len(frase)

    print('Qnt de caracteres',contador)
