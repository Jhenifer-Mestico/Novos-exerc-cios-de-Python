nome = input('Digite um nome:')
sobrenome = input('Digite seu sobrenome:')

email = nome + '.' + sobrenome + '@cruzeirodosul.edu.br'

print(email)
